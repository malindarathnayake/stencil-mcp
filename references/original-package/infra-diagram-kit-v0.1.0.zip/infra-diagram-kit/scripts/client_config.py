#!/usr/bin/env python3
"""Create local configuration snippets; never edit a client's live settings."""
from pathlib import Path
import json,sys,os,shlex,subprocess
ROOT=Path(__file__).resolve().parents[1]
def main():
    out=ROOT/'config';out.mkdir(exist_ok=True)
    interpreter=str(Path(sys.executable).resolve());server=str(ROOT/'server.py')
    exports=str(Path.home()/'infra-diagram-exports')
    entry={'command':interpreter,'args':[server],'env':{'INFRA_DIAGRAM_OUTPUT_DIR':exports}}
    code={'mcpServers':{'infra-diagrams':dict(entry,type='stdio')}}
    desktop={'mcpServers':{'infra-diagrams':entry}}
    (out/'local.mcp.json').write_text(json.dumps(code,indent=2)+'\n')
    (out/'local.claude-desktop.json').write_text(json.dumps(desktop,indent=2)+'\n')
    # JSON-escaped basic strings are valid TOML strings for these local filesystem paths.
    toml='[mcp_servers.infra-diagrams]\ncommand = '+json.dumps(interpreter)+'\nargs = '+json.dumps([server])+'\nstartup_timeout_sec = 10\ntool_timeout_sec = 30\n\n[mcp_servers.infra-diagrams.env]\nINFRA_DIAGRAM_OUTPUT_DIR = '+json.dumps(exports)+'\n'
    (out/'local.codex.toml').write_text(toml)
    quote=subprocess.list2cmdline if os.name=='nt' else shlex.join
    print('Wrote configuration snippets under: '+str(out))
    print('Live client settings were not changed. Registration commands:')
    print(quote(['codex','mcp','add','infra-diagrams','--',interpreter,server]))
    print(quote(['claude','mcp','add','--transport','stdio','--scope','user','infra-diagrams','--',interpreter,server]))
if __name__=='__main__':main()
